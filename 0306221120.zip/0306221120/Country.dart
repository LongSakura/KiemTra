class Country {
  final String officialName;
  final String capital;
  final int population;
  final String region;
  final String currencies;
  final String timezone;
  final String flag;

  Country({
    required this.officialName,
    required this.capital,
    required this.population,
    required this.region,
    required this.currencies,
    required this.flag,
    required this.timezone,
  });

  factory Country.fromJson(Map<String, dynamic> json) {
    return Country(
      officialName: json['name']['nativeName']['vie']['official'].toString(),
      capital: json['capital'][0],
      population: json['population'],
      region: json['region'],
      timezone: json['timezones'][0],
      currencies: json['currencies']['VND']['name'],
      flag: json['flags']['png'],
    );
  }
}

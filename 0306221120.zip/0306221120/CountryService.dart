import 'package:country_c01/Country.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class CountryService {
  static const baseUrl = 'https://restcountries.com/v3.1/name/';

  Future<Country?> searchCountry(String keyword) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl$keyword'));

      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        return Country.fromJson(data[0]);
      } else if (response.statusCode == 404) {
        return null;
      }
    } catch (e) {
      print('Lỗi: $e');
    }
    return null;
  }
}
